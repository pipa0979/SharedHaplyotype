//============================================================================
// Name        : SharedHaplotypeMatching.cpp
// Author      : Piyush
// Version     :
// Copyright   :
// Description : Main
//============================================================================
#include <iostream>
#include <cstdlib>
#include "ReadFiles.hpp"
#include "Part.hpp"
using namespace std;

int main(int argc,char *argv[]) {

ReadFiles inpfile;
if(!inpfile.readFile(argv[3]))
{
	cerr<<"Couldn't open file "<<argv[3]<<" program is exiting"<<endl;
	exit(0);
}
part ind1(inpfile);
part ind2(inpfile);
part compute;
compute.computation_haplotype(ind1,ind2);






return 0;
}
