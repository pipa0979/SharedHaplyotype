/*
 * OutputFile.hpp
 *
 *  Created on: Feb 22, 2016
 *      Author: root
 */

#ifndef OUTPUTFILE_HPP_
#define OUTPUTFILE_HPP_

class OutputHaplotypeMatch
{
	unsigned long int ind1;
	unsigned long int ind2;
	unsigned long int chr;
	unsigned long int start;
	unsigned long int end;
	unsigned long int bp_distance;
	unsigned long int hap1;
	unsigned long int hap2;

};


#endif /* OUTPUTFILE_HPP_ */
